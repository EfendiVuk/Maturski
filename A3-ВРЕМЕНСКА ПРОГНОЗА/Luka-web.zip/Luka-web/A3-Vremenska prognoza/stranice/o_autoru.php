<?php
	require_once('../template/header.html');
?>
<span id="o_autoru">
<p>Ime:</p>
<p>Prezime</p>
<p>E-mail</p>
<p>Ime aplikacije: <i>Vremenska prognoza</i></p>
<p>Datum kreiranja:</p>
</span>
</body>
</html>