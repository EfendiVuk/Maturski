<?php
	require_once('../template/header.html');
?>
<span id="uputstvo">
Веб апликација има могућност да
на форми избор за десет градова или локација у Србији. 
</span>
</body>
</html>